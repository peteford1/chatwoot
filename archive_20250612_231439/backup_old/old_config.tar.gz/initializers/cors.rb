# config/initializers/cors.rb
# ref: https://github.com/cyu/rack-cors

# font cors issue with CDN
# Ref: https://stackoverflow.com/questions/56960709/rails-font-cors-policy
Rails.application.config.middleware.insert_before 0, Rack::Cors do
  allow do
    origins '*'
    resource '/packs/*', headers: :any, methods: [:get, :options]
    resource '/audio/*', headers: :any, methods: [:get, :options]
    # Make the public endpoints accessible to the frontend
    resource '/public/api/*', headers: :any, methods: :any

    if ActiveModel::Type::Boolean.new.cast(ENV.fetch('CW_API_ONLY_SERVER', false)) || Rails.env.development?
      resource '*', headers: :any, methods: :any, expose: %w[access-token client uid expiry]
    end
  end
end

################################################
######### Action Cable Related Config ##########
################################################

# Mount Action Cable inside main process (recommended for Azure Container Apps)
# 2025-06-03 23:58:00 - Enabled Action Cable for real-time functionality
# Previous: Rails.application.config.action_cable.mount_path = nil
Rails.application.config.action_cable.mount_path = '/cable'

# For Azure Container Apps deployment - allow connections from your domain
Rails.application.config.action_cable.allowed_request_origins = [
  'https://chatwoot-backend-test.calmmushroom-30b1c815.eastus.azurecontainerapps.io',
  /https:\/\/.*\.azurecontainerapps\.io/
]

# To Enable connecting to the API channel public APIs
# ref : https://medium.com/@emikaijuin/connecting-to-action-cable-without-rails-d39a8aaa52d5
Rails.application.config.action_cable.disable_request_forgery_protection = true
